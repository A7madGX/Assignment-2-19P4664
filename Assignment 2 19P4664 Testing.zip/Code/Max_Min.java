public class Max_Min {

    public int is_Max(int [] a){
        int MAX;
        if (a.length != 0) {
            MAX = a[0];
            for (int i = 1; i < a.length; i++) {
                if (a[i] > MAX)
                    MAX = a[i];
            }
            return MAX;
        }
        else
            return -1;
    }

    public int is_Min(int [] a){
        int MIN;
        if (a.length != 0) {
            MIN = a[0];
            for (int i = 1; i < a.length; i++) {
                if (a[i] < MIN)
                    MIN = a[i];
            }
            return MIN;
        }
        else
            return -1;
    }
}
