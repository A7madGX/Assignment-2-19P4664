public class Even_Odd {

    public String isEvenOrOdd(int n){
        if (n%2 == 0)
            return "Even";
        else
            return "Odd";
    }
}
