import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Even_Odd_Test {

    Even_Odd test = new Even_Odd();

    @Test
    public void isZeroEven(){ assertEquals("Even", test.isEvenOrOdd(0)); }

    @Test
    public void isFourEven(){
        assertEquals("Even", test.isEvenOrOdd(4));
    }

    @Test
    public void isEighteenEven(){
        assertEquals("Even", test.isEvenOrOdd(18));
    }

    @Test
    public void isTwentyTwoEven(){
        assertEquals("Even", test.isEvenOrOdd(22));
    }

    @Test
    public void isOneOdd(){
        assertEquals("Odd", test.isEvenOrOdd(1));
    }

    @Test
    public void isThirstyOneOdd(){
        assertEquals("Odd", test.isEvenOrOdd(31));
    }

    @Test
    public void isSixtyOneOdd(){
        assertEquals("Odd", test.isEvenOrOdd(61));
    }

    @Test
    public void isOneHundredFiveOdd(){ assertEquals("Odd", test.isEvenOrOdd(105)); }

}