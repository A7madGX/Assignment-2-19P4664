public class Watch_Function {
    public static String watchfunc(String in, Watch watch) {
        String str = in;
        char input = str.charAt(0);
        int i = 0;
        while (i < str.length()) {
            if (input == 'a' || input == 'b' || input == 'c' || input == 'd') {
                if (watch.get_State().equals("normal")) {
                    if (watch.get_InnerState().equals("Time")) {
                        if (input == 'a') {
                            watch.set_InnerState("Date");
                        } else if (input == 'b') {
                            watch.set_State("Alarm");
                            watch.set_InnerState("Alarm");
                        } else if (input == 'c') {
                            watch.set_State("Update");
                            watch.set_InnerState("min");
                        }
                    } else if (watch.get_InnerState().equals("Date")) {
                        if (input == 'a') {
                            watch.set_InnerState("Time");
                        } else if (input == 'b') {
                            watch.set_State("Alarm");
                            watch.set_InnerState("Alarm");
                        } else if (input == 'c') {
                            watch.set_State("Update");
                            watch.set_InnerState("min");
                        }
                    }
                } else if (watch.get_State().equals("Alarm")) {
                    if (input == 'a') {
                        watch.set_InnerState("Chime");
                    }
                } else if (watch.get_State().equals("Update")) {
                    if (watch.get_InnerState().equals("min")) {
                        if (input == 'a') {
                            watch.set_InnerState("hour");
                        } else if (input == 'b') {
                            if (watch.get_Minutes() < 60) {
                                int m = watch.get_Minutes();
                                watch.set_Minutes(++m);
                            } else watch.set_Minutes(0);
                        }
                    } else if (watch.get_InnerState().equals("hour")) {
                        if (input == 'a') {
                            watch.set_InnerState("day");
                        } else if (input == 'b') {
                            if (watch.get_Hour() < 24) {
                                int h = watch.get_Hour();
                                watch.set_Hour(++h);
                            } else watch.set_Hour(0);
                        }
                    } else if (watch.get_InnerState().equals("day")) {
                        if (input == 'a') {
                            watch.set_InnerState("month");
                        } else if (input == 'b') {
                            if (watch.get_Day() < 31) {
                                int d = watch.get_Day();
                                watch.set_Day(++d);
                            } else watch.set_Day(0);
                        }
                    } else if (watch.get_InnerState().equals("month")) {
                        if (input == 'a') {
                            watch.set_InnerState("year");
                        } else if (input == 'b') {
                            int m = watch.get_Month();
                            watch.set_Month(++m);
                        }
                    } else if (watch.get_InnerState().equals("year")) {
                        if (input == 'a') {
                            watch.set_State("normal");
                            watch.set_InnerState("Time");
                        } else if (input == 'b') {
                            int y = watch.get_Year();
                            watch.set_Year(++y);
                        }
                    }
                }
            } else {
                watch.set_State("Error");
                break;
            }
            input = str.charAt(i++);
        }
        if (!watch.get_State().equals("Error")) {
            String y = Integer.toString(watch.get_Year());
            String m = Integer.toString(watch.get_Month());
            String d = Integer.toString(watch.get_Day());
            return y + '-' + m + '-' + d;
        }else return "Error wrong input. input can only be (a,b,c,d)";

    }
}
