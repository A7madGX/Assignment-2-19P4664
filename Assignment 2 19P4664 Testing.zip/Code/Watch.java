public class Watch {

    private String state = "normal";
    private String innerstate = "Time";
    private int Minutes = 0, Hour = 0, Day = 1, Month = 1 , Year = 2000;

    public String get_State() {
        return state;
    }

    public void set_State(String state) {
        this.state = state;
    }

    public String get_InnerState() {
        return innerstate;
    }

    public void set_InnerState(String innerstate) {
        this.innerstate = innerstate;
    }

    public int get_Month() {
        return Month;
    }

    public void set_Month(int Month) {
        this.Month = Month;
    }
    public int get_Minutes() {
        return Minutes;
    }

    public void set_Minutes(int Minutes) {
        this.Minutes = Minutes;
    }
    public int get_Year() {
        return Year;
    }

    public void set_Year(int Year) {
        this.Year = Year;
    }

    public int get_Hour() {
        return Hour;
    }

    public void set_Hour(int Hour) {
        this.Hour = Hour;
    }

    public int get_Day() {
        return Day;
    }

    public void set_Day(int Day) {
        this.Day = Day;
    }

}
