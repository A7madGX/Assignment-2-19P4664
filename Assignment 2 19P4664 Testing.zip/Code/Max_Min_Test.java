import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Max_Min_Test {

    Max_Min Max_Min = new Max_Min();

    @Test
    public void x(){
        int []array = {};
        assertEquals(-1, Max_Min.is_Max(array));
        assertEquals(-1, Max_Min.is_Min(array));
    }

    @Test
    public void y(){
        int []array = {25,89,2,-1,-105,652,998};
        assertEquals(998, Max_Min.is_Max(array));
        assertEquals(-105, Max_Min.is_Min(array));
    }

    @Test
    public void z(){
        int []array = {-15,0,-89,-1,-105,-33,-546};
        assertEquals(0, Max_Min.is_Max(array));
        assertEquals(-546, Max_Min.is_Min(array));
    }
}